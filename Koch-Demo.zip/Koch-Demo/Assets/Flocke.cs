﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//try size change individually for every game object
//without drawing new flake
//and maybe make alpha value change dynamically on glow shader
//same thing might work for some intensity values
//you can even make anti-glow effects with negative values :D
//noch einen mode mit 3 unterschiedlichen farben machen (orgi)
//vlt noch für die planes auf shift langsamer machen können beim scalen
//vlt noch die direction vom directional light ändern um effekt zu bekommen?



// beim glühwürmchen mode vlt spheres forcen, die wie navi von zelda immer son bisschen
// größer und kleiner werden vlt ne innere mit ner äußeren das wär voll pornös, würde 
// aber vermutlich auch viel leisung zocken, am besten eigenes fairy object machen :D
public class Flocke : MonoBehaviour
{
    private Material material1;
    private Material material2;
    private Material material3;
    private Vector3 position;
    private double angle;
    private GameObject turtle;
    private uint objectCount;
    private uint depth;
    private List<GameObject> elements;
    private float zScale;
    private float size;
    private PrimitiveType primitiveType;
    private short primitiveTypeToggle;

    // vlt noch ne extra variable für xy scale 
    // dass man wenigstens beim switch von den
    // geometrischen primitiven den xyScale behält
    // und somit nen geilen direkten vergleich hat
    // is aber nicht so einfach, da der tatsächliche
    // scale erst mal rausgefunden werden muss
    // am besten einfach in ein listenelement gucken
    // man kann aber auch drauf waynen

    // Use this for initialization
    void Start()
    {
        this.primitiveType = PrimitiveType.Cube;
        this.primitiveTypeToggle = 0;
        this.size = 1.0f;
        //this.material = Resources.Load("Materials/Emissive_Yellow", typeof(Material)) as Material;
        this.material1 = Resources.Load("Materials/glowgreen", typeof(Material)) as Material;
        this.material2 = Resources.Load("Materials/glowblue", typeof(Material)) as Material;
        this.material3 = Resources.Load("Materials/glowmagenta", typeof(Material)) as Material;
        this.zScale = .1f;
        this.elements = new List<GameObject>();
        this.angle = .0d;
        this.depth = 0;
        this.objectCount = 0;
        this.position = Vector3.zero;
        this.DrawFlake(depth, this.size);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            this.depth++;
            this.DestroyElements();
            this.DrawFlake(depth, this.size);
            Debug.Log("Iterations: " + this.depth + ", Object Count: " + this.objectCount + ", Primitive Type: " + this.primitiveType);
        }
        else if (Input.GetKeyDown(KeyCode.DownArrow) && this.depth > 0)
        {
            this.depth--;
            this.DestroyElements();
            this.DrawFlake(depth, this.size);
            Debug.Log("Iterations: " + this.depth + ", Object Count: " + this.objectCount + ", Primitive Type: " + this.primitiveType);
        }
        else if (Input.GetKey(KeyCode.LeftArrow) && this.zScale > .001f)
        {
            this.ScaleZDown(.005f);
            //this.DestroyElements();
            //this.Flake(depth, this.size);
        }
        else if (Input.GetKey(KeyCode.RightArrow))
        {
            this.ScaleZUp(.005f);
            //this.DestroyElements();
            //this.Flake(this.depth, this.size);
        }
        else if (Input.GetKey(KeyCode.KeypadPlus) || Input.GetKey(KeyCode.Plus)) //normal plus key might not work
        {
            this.size += .05f;
            this.DestroyElements();
            this.DrawFlake(this.depth, this.size);
        }
        else if (Input.GetKey(KeyCode.KeypadMinus) || Input.GetKey(KeyCode.Minus))
        {
            this.size -= .05f;
            if(this.size < .001f)
            {
                this.size = .001f;
            }
            this.DestroyElements();
            this.DrawFlake(this.depth, this.size);
        }
        if (Input.GetKeyDown(KeyCode.LeftAlt))
        {
            this.primitiveTypeToggle++;
            this.primitiveTypeToggle %= 5;
            this.TogglePrimitiveType(this.primitiveTypeToggle);
            this.DestroyElements();
            this.DrawFlake(this.depth, this.size);
        }
        if (Input.GetKeyDown(KeyCode.AltGr) || Input.GetKeyDown(KeyCode.RightAlt))
        {
            this.primitiveTypeToggle--;
            if (this.primitiveTypeToggle < 0)
            {
                this.primitiveTypeToggle = 4;
            }
            this.TogglePrimitiveType(this.primitiveTypeToggle);
            this.DestroyElements();
            this.DrawFlake(this.depth, this.size);
        }
        if (Input.GetKey(KeyCode.KeypadDivide))
        {
            this.ScaleXYDown(.005f);
        }
        else if(Input.GetKey(KeyCode.KeypadMultiply))
        {
            this.ScaleXYUp(.005f);
        }
        // auf space/backspace noch die color bzw das material
        // für scale jeder art (size, zScale) am besten eine extra Methode machen
        // bei der nicht extra ne neue Flake gezeichnet werden muss
        // das wird aber sicherlich die proportionen der kurve verändern
        // es sei denn, man passt die position an, aber der effekt ist bestimmt eh schmuck^^
        // über jedes GO zu iterieren, ist wohl noch etwas schneller als die rekursion bei
        // hoher tiefe
    }

    private void ScaleZUp(float step)
    {
        if(step > .0f)
        {
            this.zScale += step;
            foreach (GameObject turtle in this.elements)
            {
                turtle.transform.localScale += new Vector3(.0f, .0f, step);
            }
        }
    }

    private void ScaleZDown(float step)
    {
        if(step > .0f)
        {
            this.zScale -= step;
            if (this.zScale < .001f)
            {
                this.zScale = .001f;
                foreach(GameObject turtle in this.elements)
                {
                    float xyScale = turtle.transform.localScale.x;
                    turtle.transform.localScale = new Vector3(xyScale, xyScale, this.zScale);
                }
            }
            else
            {
                foreach(GameObject turtle in this.elements)
                {
                    turtle.transform.localScale -= new Vector3(.0f, .0f, step);
                }
            }
        }
    }

    private void ScaleXYDown(float step)
    {
        if (step > .0f)
        {
            foreach(GameObject turtle in this.elements)
            {
                if(turtle.transform.localScale.x - step >= .001f)
                {
                    turtle.transform.localScale -= new Vector3(step, step, .0f);
                }
                else
                {
                    turtle.transform.localScale = new Vector3(.001f, .001f, this.zScale);
                }
            }
        }
    }

    private void ScaleXYUp(float step)
    {
        if (step > .0f)
        {
            foreach (GameObject turtle in this.elements)
            {
                turtle.transform.localScale += new Vector3(step, step, .0f);
            }
        }
    }

    private void TogglePrimitiveType(short primitiveTypeToggle)
    {
        switch (primitiveTypeToggle)
        {
            case 0:
                this.primitiveType = PrimitiveType.Cube;
                break;
            case 1:
                this.primitiveType = PrimitiveType.Sphere;
                break;
            case 2:
                this.primitiveType = PrimitiveType.Capsule;
                break;
            case 3:
                this.primitiveType = PrimitiveType.Cylinder;
                break;
            case 4:
                this.primitiveType = PrimitiveType.Plane;
                break;
        }
    }

    private void DrawFlake(uint depth, float size)
    {
        this.angle = 60.0d;
        this.DrawCurve(this.depth, this.size, this.material1);
        this.angle = -60.0d;
        this.DrawCurve(this.depth, this.size, this.material2);
        this.angle = 180.0d;
        this.DrawCurve(this.depth, this.size, this.material3);
        Debug.Log("Iterations: " + this.depth + ", Object Count: " + this.objectCount + ", Primitive Type: " + this.primitiveType);
    }

    private void DrawCurve(uint depth, float size, Material material)
    {
        if(depth == 0)
        {
            this.Move(size, material);
        }
        else
        {
            this.DrawCurve(depth - 1, size / 3.0f, material);
            this.Turn(60.0d);
            this.DrawCurve(depth - 1, size / 3.0f, material);
            this.Turn(-120.0d);
            this.DrawCurve(depth - 1, size / 3.0f, material);
            this.Turn(60.0d);
            this.DrawCurve(depth - 1, size / 3.0f, material);
        }
    }

    private void Move(float step, Material material)
    {
        this.turtle = GameObject.CreatePrimitive(this.primitiveType);

        this.elements.Add(turtle);

        this.objectCount++;

        this.position.x += step * (float)Math.Cos(ToRadians(this.angle));
        this.position.y += step * (float)Math.Sin(ToRadians(this.angle));

        this.turtle.transform.position = this.position;
        this.turtle.transform.localScale = new Vector3(step, step, this.zScale);

        this.turtle.GetComponent<Renderer>().material = material;
    }

    private void Turn(double delta)
    {
        this.angle += delta;
    }

    private void DestroyElements()
    {
        foreach(GameObject turtle in this.elements)
        {
            Destroy(turtle);
        }
        this.elements.Clear();
        this.objectCount = 0;
    }

    private static double ToRadians(double val)
    {
        return (Math.PI / 180.0d) * val;
    }
}