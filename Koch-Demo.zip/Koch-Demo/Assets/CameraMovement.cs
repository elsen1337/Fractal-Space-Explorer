﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMovement : MonoBehaviour {

    enum Direction { Forward, Back, Left, Right, Up, Down };

    private Camera camera;

	// Use this for initialization
	void Start () {
        this.camera = Camera.main;
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKey(KeyCode.W))
            this.Move(Direction.Forward);
        if (Input.GetKey(KeyCode.S))
            this.Move(Direction.Back);
        if (Input.GetKey(KeyCode.A))
            this.Move(Direction.Left);
        if (Input.GetKey(KeyCode.D))
            this.Move(Direction.Right);
        if (Input.GetKey(KeyCode.Q))
            this.Move(Direction.Up);
        if (Input.GetKey(KeyCode.E))
            this.Move(Direction.Down);
    }

    private void Move (Direction direction)
    {
        switch(direction)
        {
            case Direction.Forward:
                this.camera.transform.Translate(new Vector3(.0f, .0f, .005f));
                break;
            case Direction.Back:
                this.camera.transform.Translate(new Vector3(.0f, .0f, -.005f));
                break;
            case Direction.Left:
                this.camera.transform.Translate(new Vector3(-.005f, .0f, .0f));
                break;
            case Direction.Right:
                this.camera.transform.Translate(new Vector3(.005f, .0f, .0f));
                break;
            case Direction.Up:
                this.camera.transform.Translate(new Vector3(.0f, .005f, .0f));
                break;
            case Direction.Down:
                this.camera.transform.Translate(new Vector3(.0f, -.005f, .0f));
                break;
        }
    }
}
